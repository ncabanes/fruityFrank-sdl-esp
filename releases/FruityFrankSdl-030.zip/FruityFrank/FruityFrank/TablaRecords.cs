/* --------------------------------------------------         
TablaRecords: tabla de mejores puntuaciones
Parte de Fruity Frank - Remake

@see Juego
@author  Nacho

Versiones:
   
Num.   Fecha       Por / Cambios
---------------------------------------------------
0.30  01-Ago-2017  Nacho Cabanes
                   Primera versi�n 2017, id�ntica a la 0.20 de 2008
                   (esqueleto vac�o)
---------------------------------------------------- */

public class TablaRecords
{

}
