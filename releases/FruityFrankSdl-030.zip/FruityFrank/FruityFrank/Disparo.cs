/* --------------------------------------------------         
Disparo: uno de los tipos de elementos graficos del juego
Parte de Fruity Frank - Remake

@see ElemGrafico Juego
@author Nacho

Versiones:
   
Num.   Fecha       Por / Cambios
---------------------------------------------------
0.20  08-Dic-2008  Nacho Cabanes
                    Clase vacia, generado semi-autom. 
 ---------------------------------------------------- */

public class Disparo : ElemGrafico
{

}
